---
name: reference-analyzer
description: Analyse a reference video in Harry AI FILM STUDIO — shot segmentation, cut timing, pacing, keyframes — and summarise its edit structure for recreation or style matching. Use when the user uploads or names a reference clip and asks "how is this cut", "match this pacing" or "recreate this".
---

# Reference Analyzer

## Requires
Studio running with ffmpeg (native or WSL). The clip uploaded as an asset with rights confirmed.

## Inputs
Asset id of the reference video; optional scene-change threshold (default 0.3; lower = more cuts).

## Outputs
`POST /api/assets/:id/analyze` → segments (start/end/duration), keyframe assets per segment, edit rhythm (shot count, average shot length, cuts/min, pacing class). A plain-language read of the structure.

## Procedure
1. Run analysis. If segment count looks wrong (whip pans/flashes split shots, dissolves missed), re-run with threshold 0.4 or 0.2 and say which you trust.
2. Look at the keyframes (`GET /api/assets/:kf/file`) and describe each shot: size, angle, move, subject — mark these as your visual reading (INFERRED), timing as MEASURED.
3. Hand the analysis id to motion-transfer-planner / video-edit-planner if the user wants a recreation.

## Limits
Detects hard cuts by frame difference only; dissolves and match cuts may be missed. No shot-type classifier — shot descriptions are your reading of keyframes.

## Failure conditions
Non-video asset → 400. Missing ffmpeg → error explains how to install (do not install without approval).

## Evaluation case
Fixture: 6 s clip = 3 s testsrc2 + 3 s SMPTE bars (built in `tests/e2e/workflow.test.js`).
Pass when exactly 2 segments, first ends at 3.0 s ± 0.1, two keyframe assets registered. Automated: e2e test "M3: reference analysis…".
