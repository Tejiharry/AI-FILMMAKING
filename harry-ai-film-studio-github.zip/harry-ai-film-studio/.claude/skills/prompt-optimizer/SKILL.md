---
name: prompt-optimizer
description: Improve how Harry AI FILM STUDIO compiles ShotSpecs into provider prompts — wording, ordering, redundancy, contradictions, provider-specific tokens — and prove the change with tests. Use when generations ignore a setting, prompts read badly, or a new provider needs its own phrasing. Developer-facing: edits server/engine/*.
---

# Prompt Optimizer

## Requires
Repo checkout; `npm test` passing before you start.

## Inputs
A failing case: the ShotSpec (from the job's `spec_snapshot`), the compiled prompt (`request.prompt`) and what went wrong in the output.

## Outputs
A change to `server/engine/cinematography.js` (phrases) or `server/engine/compiler.js` (ordering/logic), plus a unit test that pins the behaviour.

## Procedure
1. Reproduce: compile the spec in a unit test and print the prompt.
2. Diagnose: contradiction (e.g. tripod + dolly), redundancy ("slow … slow"), defaults leaking into prompts, ordering (subject/action should precede camera and style), missing reference tokens.
3. Change the smallest thing; keep every phrase concrete and visual. Provider-specific syntax (e.g. `@Image1`) belongs in the adapter's `refToken`, never in the engine.
4. Add/extend a test in `tests/unit/engine.test.js`; run `npm test`.
5. Never claim a wording change improves output quality without a benchmark run (see docs/BENCHMARK.md) — record it as a hypothesis until measured.

## Failure conditions
Changing a phrase used by presets or the Director without re-running the Director test; adding unsupported API params to make a setting "guaranteed".

## Evaluation case
Bug: "slow dolly push-in toward the subject, slow and deliberate" (fixed 2026-10-18).
Pass when the compiled prompt for `push_in` + `slow` contains the speed once and the unit test asserting no duplicate passes.
