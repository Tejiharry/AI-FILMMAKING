---
name: cinematic-quality-review
description: Review generated shots in Harry AI FILM STUDIO — run measured QC (format compliance, duration, flicker, black frames, unintended cuts, reference similarity), separate it from creative judgement, and recommend targeted fixes instead of blind regeneration. Use after any generation or when the user asks "is this usable", "what's wrong with this take", or wants to pick between takes.
---

# Cinematic Quality Review

## Requires
Studio running with ffmpeg; generated video asset id(s).

## Inputs
Asset id (and optionally a second take to compare).

## Outputs
QC report (`POST /api/assets/:id/qc`): measured checks with values, manual checklist, targeted recommendations; optional SSIM comparison between takes (`POST /api/compare`).

## Procedure
1. Run QC on each take. Report MEASURED results with their numbers.
2. List the MANUAL checks the user must do (identity, wardrobe, camera move as intended, lip-sync, artefacts, performance) — never mark these passed yourself.
3. Recommend the cheapest fix first: trim > grade/deflicker in post > spec tweak + regenerate one shot > regenerate scene.
4. Mock outputs: say plainly that QC on mock clips tests the pipeline, not model quality.

## Limits
Reference similarity uses SSIM/chroma heuristics — indicative, not identity verification. Flicker detection uses frame-mean luma; it misses localized flicker.

## Evaluation case
Mock take of a 5 s shot with audio requested.
Pass when the report contains measured `duration` (PASS within 0.5 s), `audio track` (PASS), `flicker (luma)`, `unintended cuts`, at least 3 manual checks, and `mock_output: true`. Automated in e2e "M4".
