---
name: seedance-orchestrator
description: Run, monitor and troubleshoot BytePlus ModelArk Seedance 2.5 generations through Harry AI FILM STUDIO — connection test, plan validation, cost estimate, approval, task tracking, failures, reconciliation. Use whenever a real (paid) Seedance generation is being prepared or has gone wrong. Never spends money without the user's explicit approval of the exact amount.
---

# Seedance Orchestrator

## Requires
Studio running; ModelArk API key saved in Model Settings (encrypted server-side — never ask the user to paste it into chat); account activated for `dreamina-seedance-2-5-260628` (BytePlus requires ≥ $30 balance/plan/pack).

## Inputs
Shot id(s); intended resolution; budget limits.

## Outputs
Validated plans, approved jobs, finished takes in the asset library, an honest status report (cost estimate vs actual tokens).

## Procedure
1. `POST /api/providers/seedance/test` — free (lists tasks). Fails → auth/region/model-access issue; stop.
2. `POST /api/shots/:id/plan {provider:'seedance'}` — fix every error. Common: video refs need hosted URL; first/last frame cannot mix with references; real-face refs refused; durations 4–30 s.
3. Present: prompt, control report, estimate + basis (`(input video s + output s) × W × H × 24 / 1024` tokens at $/M), confidence.
4. Create the job (`/generate`). It waits in `awaiting_approval`. **Only the user approves** — in the UI or by explicitly confirming the exact USD amount in chat that message. Never approve on your own initiative.
5. Track via `GET /api/jobs/:id` or the Jobs view. Failed jobs: moderation (not billed), invalid request, quota/rate limit.
6. `needs_review` = submit outcome unknown: use Reconcile (lists recent provider tasks) before any retry — never blind-resubmit.

## Limits
Output 24 fps, mono audio, URLs expire after 24 h (the runner downloads immediately). `seed` and `camera_fixed` are not documented for 2.5 and are never sent. Punjabi is not a documented language.

## Evaluation case
Stubbed API (e2e "M1: Seedance…"): pass when nothing is POSTed before approval, a wrong confirmation amount is refused (400), a per-job budget breach is refused (402), exactly one POST is made after approval with model `dreamina-seedance-2-5-260628`, `ratio: adaptive` for a first-frame job and no `seed/camera_fixed/frames`, and the result + last frame land in the library.
