---
name: motion-transfer-planner
description: Plan a Genjutsu-style motion transfer or Katana-style reference recreation in Harry AI FILM STUDIO — keep a reference clip's camera, timing and body motion while replacing cast, product or world. Use when the user wants "the same move/edit but with my character/product".
---

# Motion Transfer Planner

## Requires
Studio running; reference video asset (+ analysis id for recreation); library references (`@handles`) for the replacement subjects.

## Inputs
Source asset id, transform type (`motion_transfer` or `recreate`), replacement handles, creative brief.

## Outputs
A new scene of draft shots (`POST /api/projects/:id/transform`) — the source is never modified — plus a feasibility statement.

## Procedure
1. `recreate` (orchestrated): one shot per detected segment, keyframe attached as `reference_image`, duration = segment length clamped to 4–30 s. Short source cuts (< 4 s) get padded — warn that the edit will need trimming in post.
2. `motion_transfer` (EXPERIMENTAL): source attached as `reference_video` (2–30 s). On Seedance the video must have a hosted `https://` or `asset://` URL (set Remote URL on the asset) — base64 video is not accepted.
3. Check the plan with the target provider (`POST /api/shots/:id/plan`) and surface every error.
4. After generation, compare source vs result (`POST /api/compare`) and have the user judge motion fidelity by eye.

## Limits (always tell the user)
- Motion fidelity is not guaranteed; regenerated footage is new footage, not an edit of the original.
- Seedance 2.5 refuses reference media with real faces unless it is an authorized `asset://` ID or a recent trusted Seedance output.
- Combined source ≤ 30 s of reference video per request.

## Evaluation case
Source: the two-shot fixture clip, type `recreate`, brief "with Mira", refs `@mira`.
Pass when 2 shots are created in a new scene, each with a `reference_image` keyframe and duration ≥ 4 s, and the original asset is unchanged (same sha256). Automated in e2e "M3".
