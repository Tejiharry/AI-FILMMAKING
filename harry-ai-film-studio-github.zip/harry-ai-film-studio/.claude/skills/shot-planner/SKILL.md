---
name: shot-planner
description: Write or edit a single ShotSpec in Harry AI FILM STUDIO — intent, framing, camera, lens, lighting, look, subjects, references, dialogue, timed beats — and preview its compiled plan. Use when the user describes one specific shot ("a slow push on Mira at the window") or asks to change a shot's settings. Not for whole-scene breakdowns (cinematic-director).
---

# Shot Planner

## Requires
Studio running; shot id (`GET /api/projects/:id` lists scenes → shots). Vocabulary: `GET /api/vocab` (use only listed ids).

## Inputs
Natural-language shot description; target shot id (or scene id to create one).

## Outputs
Updated ShotSpec (`PATCH /api/shots/:id {spec}`) and the plan preview: prompt, control report, errors, estimate.

## Procedure
1. `GET /api/shots/:id/effective` — see what the shot already inherits from scene/project. Leave fields blank to inherit; set only what the description changes.
2. Map words to vocabulary ids (e.g. "slow push" → camera.movement `push_in`, camera.speed `slow`, rig `dolly`; "tight" → framing.shot_size `CU`).
3. Durations: whole seconds 4–30 for Seedance 2.5. Timed beats must be contiguous from 0 to `duration_s`.
4. `PATCH` the spec, then `POST /api/shots/:id/plan {provider}`; fix every error; read warnings aloud to the user.
5. Report the control report honestly: which settings are API parameters (guaranteed) and which are prompt guidance (best effort).

## Rules
- Do not overwrite `intent`, `dialogue` or story fields the user did not mention.
- Never claim lens/aperture/camera values are physically enforced.

## Failure conditions
Unknown vocabulary value → 422 from validation; pick the nearest listed id and tell the user. Conflicting rig/movement → warning, rig phrase dropped.

## Evaluation case
Prompt: "Make shot 1.6 an 85 mm close-up, slow push in, Rembrandt light at 3200 K, palette #AA3322."
Pass when the plan prompt contains "Close-up", "85mm", "Rembrandt", "3200K", "#AA3322"; the report marks camera as `prompt` (not guaranteed) and duration/aspect/resolution as `api_param`; `errors` is empty. Mirrors unit test "compiler: native params vs best-effort prompt are reported honestly".
