---
name: camera-choreographer
description: Design camera movement and blocking for a shot or a run of shots in Harry AI FILM STUDIO — move type, speed, rig, start/end framing, timed beats and screen direction across cuts. Use when the user asks how the camera should move, wants a oner broken into beats, or wants motion continuity between consecutive shots.
---

# Camera Choreographer

## Requires
Studio running; the scene's shots (`GET /api/projects/:id`).

## Inputs
Scene/shot ids, dramatic intent per beat, any reference video of the desired move.

## Outputs
Per shot: `camera.{movement,speed,rig,notes}`, `framing.{shot_size,angle,composition}`, optional `timeline` beats; a continuity note per cut (screen direction, eyeline, motion carry-over).

## Procedure
1. Read the beats. One dominant camera idea per generated shot — models follow one clear move far better than compound moves.
2. For multi-beat moves, use `timeline` beats (contiguous, ≤ 30 s total) with a camera id per beat; otherwise split into separate shots.
3. Keep the 180° line: record which side the camera is on in `camera.notes` and keep it across the scene's singles.
4. Motion continuity between shots: plan matching move direction at the cut, or use "Continue from previous shot's last frame" (`POST /api/shots/:id/chain-from-previous`) — note this switches the shot to first-frame mode and drops reference inputs.
5. If the user has a reference move, route to motion-transfer-planner instead of describing it in words.

## Limits (state them)
Camera motion is prompt-interpreted on Seedance 2.5 — no trajectory, speed or focal-length parameter exists. Verify the move by eye; QC can only detect unintended cuts.

## Failure conditions
Tripod + travelling move → rig dropped with a warning. Timeline gaps → validation error.

## Evaluation case
Brief: "Rooftop: start wide behind Dev, push in as he reaches the edge, end on his profile, 8 s."
Pass when: one shot, `duration_s` 8, timeline `[0–4] wide, push_in` and `[4–8] profile MCU`, contiguous, plan has no errors, camera reported as best-effort.
