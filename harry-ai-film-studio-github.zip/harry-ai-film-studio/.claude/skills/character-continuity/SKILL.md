---
name: character-continuity
description: Keep characters, wardrobe, props, locations and look consistent across shots in Harry AI FILM STUDIO — build reference packs, assign @handles, choose between reference-locked and first-frame-locked shots, and check drift. Use when the user says a character "doesn't look the same", sets up a new cast member, or plans a sequence that must match.
---

# Character Continuity

## Requires
Studio running; images of each character/prop/location with usage rights (and recorded likeness consent for real people).

## Inputs
Character/prop/location names, images, stable descriptions.

## Outputs
Library references (`POST /api/projects/:id/refs`) with handles, descriptions and media; shot subjects pointing at those handles; a continuity strategy per sequence.

## Procedure
1. One reference per entity. Description = stable, visual, specific (age range, build, hair, signature wardrobe colours). Never put emotion or action in it.
2. Prefer 2–4 clean images per character (front, three-quarter, full body), consistent lighting.
3. Choose a lock mode per shot and say why:
   - Identity-locked: subjects with library images (auto-attached as `reference_image`).
   - Storyboard-locked: first frame (+ last frame), e.g. chained from the previous shot's last frame. Seedance cannot combine the two in one request.
4. Put project-wide look (palette, texture, genre) in project `shot_defaults`; per-scene location/time in scene settings.
5. After generation run cinematic-quality-review; identity is a MANUAL check — never claim consistency without the user looking.

## Limits
- Seedance 2.5 refuses real-face references unless they are authorized `asset://` IDs (BytePlus real-person verification) or Seedance/Seedream outputs from the same account < 30 days old.
- No trained identity model (unlike Higgsfield Soul ID); consistency relies on references + descriptions.

## Evaluation case
Create `@mira` with one image and description "woman, 30s, red coat"; add her as subject of a shot.
Pass when the plan's inputs include her image as `reference_image` (auto-attached) and the prompt contains "@mira (Mira: …)" replaced by `@Image1` for Seedance. Covered by unit test "compiler…" and e2e "M1: plan…".
