---
name: video-edit-planner
description: Plan targeted changes to an existing clip in Harry AI FILM STUDIO — object/subject/product swap, selective scene change (weather, time of day, prop), style transfer, extend forward/backward, or a shot revision. Use when the user wants to change part of a generated or uploaded clip rather than make a new shot.
---

# Video Edit Planner

## Requires
Studio running; source video asset id; for swaps, the replacement as a library `@handle` or a precise description.

## Inputs
Edit type (`object_swap`, `selective_change`, `style_transfer`, `extend`) or a revision of an existing shot; target and replacement wording.

## Outputs
A new scene with the planned edit shot (`POST /api/projects/:id/transform`) or a new version of a shot (`POST /api/shots/:id/revise` — keeps every previous take).

## Procedure
1. Pick the narrowest operation: revision of a shot's spec beats a full edit; an edit task beats a regeneration.
2. Edit prompts must name what changes AND what stays ("keep camera, timing, other people, background unchanged").
3. Seedance edit tasks: `ratio` adaptive and `duration` -1 are forced by the adapter; source 4–30 s; source needs a hosted/`asset://` URL.
4. After generation: run QC and `POST /api/compare {a: source, b: result}` — report the SSIM as a preservation measure.

## Limits (always tell the user)
Edits regenerate the whole clip: unaffected regions are NOT pixel-preserved. Never present an edit result as the original footage. For pixel-exact preservation, composite the changed region in Resolve/Fusion instead.

## Evaluation case
Source: fixture clip; type `object_swap`, target "the test card", replacement "a red coat".
Pass when the planned shot has `workflow: edit`, a `reference_video` input, a prompt containing both the replacement and "unchanged", and the Seedance plan reports the hosted-URL requirement as an error rather than failing silently. Automated in e2e "M3".
