---
name: cinematic-director
description: Turn a script, scene or creative brief into a structured Harry AI FILM STUDIO production plan — scenes, coverage shots and ShotSpecs — through the studio's API. Use when the user asks to "direct", "break down", "plan coverage" or "storyboard" a scene for AI generation in this project. Not for generating video (use seedance-orchestrator) or reviewing output (use cinematic-quality-review).
---

# Cinematic Director

Produces a reviewable production plan inside Harry AI FILM STUDIO. The deterministic Director (`server/engine/director.js`) is the baseline; you refine its output with filmmaking judgement.

## Requires
- Harry AI FILM STUDIO running (`npm start`, default http://127.0.0.1:4517).
- A project id (`GET /api/projects`). Ask the user which project if more than one exists.

## Inputs
Screenplay text (INT./EXT. headings, CHARACTER cues) or a prose brief; optional style notes, target runtime, aspect.

## Outputs
New scenes + draft shots in the project (never edits existing shots), each with a `director_note` rationale; a short summary of the coverage strategy per scene.

## Procedure
1. `POST /api/director/breakdown {script, project_id}` — read characters, scenes, shots, rationales.
2. Review the coverage like an editor: every speaking character covered on their own face; reactions for lines that land; inserts for plot objects; geography established before singles; no redundant angles.
3. Adjust the breakdown JSON (shot sizes, moves, lens, durations 4–15 s) — keep each change justified in `rationale`.
4. `POST /api/projects/:id/director/apply {breakdown, script, create_character_refs:true}`.
5. Tell the user what was created and what to check (identity references still need images in Reference Studio).

## Rules
- Never invent dialogue, names or story beats — use only the given text; ask when a beat is ambiguous.
- Camera/lens/light values are prompt guidance, not physical control — say so when it matters.
- Do not generate (no spend) from this skill.

## Failure conditions
- No headings/cues detected → the parser yields one UNTITLED scene; ask the user for screenplay formatting or paste per scene.
- Non-English dialogue: Seedance 2.5 does not document Punjabi; keep the original line in `dialogue.line` and flag it.

## Evaluation case
Input: the 15-line kitchen/rooftop sample in `tests/unit/engine.test.js` (`SCRIPT`).
Pass when: 2 scenes; scene 1 starts with an establishing shot; contains a letter insert, a MIRA/DEV two-shot, and a DEV reaction after "Tell me what?!"; scene 2 lighting.time_of_day = dawn; every ShotSpec validates (`validateSpec(...).ok`). Automated by `npm run test:unit` ("director: parses screenplay and builds coverage").
